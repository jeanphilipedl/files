# -*- coding: utf-8 -*-
"""
Created on Wed May  6 12:08:47 2020

@author: Administrator
"""
import sys
import time                #used to keep track of time
import numpy as np         #array library
import math

def moveForward():
    return True
    

def adjustDirection():
    pass
    

def turnLeft():
    return True

def turnRight():
    return True

def feelFront():
    return True

def feelLeft():
    return True

def feelRight():
    return True
    
