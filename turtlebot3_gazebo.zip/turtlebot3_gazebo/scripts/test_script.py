import os

class Node():
    pass

def parseInteraction(enacted_response):
    # e01,
    # e31,e41,
    # e31,e31,e41,
    INTERACTIONS = {}
    INTERACTIONS["a"] = "a"
    print(INTERACTIONS)
    if "a" in INTERACTIONS:
        print("the string")
        

interactionString = 'e01,'
print(interactionString)
parseInteraction(interactionString)
